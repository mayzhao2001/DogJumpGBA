/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 loseScreen Lose_Screen.png 
 * Time-stamp: Friday 04/09/2021, 11:28:44
 * 
 * Image Information
 * -----------------
 * Lose_Screen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSESCREEN_H
#define LOSESCREEN_H

extern const unsigned short Lose_Screen[38400];
#define LOSE_SCREEN_SIZE 76800
#define LOSE_SCREEN_LENGTH 38400
#define LOSE_SCREEN_WIDTH 240
#define LOSE_SCREEN_HEIGHT 160

#endif

