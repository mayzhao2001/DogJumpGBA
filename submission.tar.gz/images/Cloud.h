/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=50x25 Cloud Cloud.png 
 * Time-stamp: Thursday 04/08/2021, 22:29:36
 * 
 * Image Information
 * -----------------
 * Cloud.png 50@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CLOUD_H
#define CLOUD_H

extern const unsigned short Cloud[1250];
#define CLOUD_SIZE 2500
#define CLOUD_LENGTH 1250
#define CLOUD_WIDTH 50
#define CLOUD_HEIGHT 25

#endif

