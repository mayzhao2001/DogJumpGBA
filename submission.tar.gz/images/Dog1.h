/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=59x43 Dog1 Dog1.png 
 * Time-stamp: Friday 04/09/2021, 23:42:22
 * 
 * Image Information
 * -----------------
 * Dog1.png 59@43
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DOG1_H
#define DOG1_H

extern const unsigned short Dog1[2537];
#define DOG1_SIZE 5074
#define DOG1_LENGTH 2537
#define DOG1_WIDTH 59
#define DOG1_HEIGHT 43

#endif

