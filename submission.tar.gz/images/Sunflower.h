/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=24x45 Sunflower Sunflower.png 
 * Time-stamp: Friday 04/09/2021, 23:53:23
 * 
 * Image Information
 * -----------------
 * Sunflower.png 24@45
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SUNFLOWER_H
#define SUNFLOWER_H

extern const unsigned short Sunflower[1080];
#define SUNFLOWER_SIZE 2160
#define SUNFLOWER_LENGTH 1080
#define SUNFLOWER_WIDTH 24
#define SUNFLOWER_HEIGHT 45

#endif

