/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=59x43 Dog2 Dog2.png 
 * Time-stamp: Thursday 04/08/2021, 22:27:47
 * 
 * Image Information
 * -----------------
 * Dog2.png 59@43
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DOG2_H
#define DOG2_H

extern const unsigned short Dog2[2537];
#define DOG2_SIZE 5074
#define DOG2_LENGTH 2537
#define DOG2_WIDTH 59
#define DOG2_HEIGHT 43

#endif

