/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=59x43 Dog3 Dog3.png 
 * Time-stamp: Thursday 04/08/2021, 22:28:16
 * 
 * Image Information
 * -----------------
 * Dog3.png 59@43
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DOG3_H
#define DOG3_H

extern const unsigned short Dog3[2537];
#define DOG3_SIZE 5074
#define DOG3_LENGTH 2537
#define DOG3_WIDTH 59
#define DOG3_HEIGHT 43

#endif

