README

This is a little game I worked on for my CS 2110 course 
at Georgia Tech. The dog in the game is Sideways, 
the unofficial mascot of the university. 

Keys

Start -> Enter
Select -> Backspace
Up -> Up

*The keys may not be responsive at first,
if this is the case, use Alt+Shift+1 when you load
the game in order to manually configure the keys*

Controls
jump -> up
restart game during gameplay -> select

